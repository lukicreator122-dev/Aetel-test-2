const {
  createAgentTriggerService,
  createCheckpointDeletionReclaimer,
  createAgentContinuationResolver,
  createAgentEventContinueResolver,
  createSubagentCompletionWakeupResolver,
  SUBAGENT_COMPLETION_SOURCE,
  createBackgroundToolCompletionWakeupResolver,
  createBackgroundToolDeadClaimRecovery,
  BACKGROUND_TOOL_COMPLETION_SOURCE,
  createAgentQueuedTurnLifecycle,
  completePromotedSteerHandoff,
  AGENT_QUEUED_TURN_SOURCE,
  GenerationJobManager,
} = require('@librechat/api');
const methods = require('~/models');

const getGenerationAdmissionEvidence = (userId, clientRequestId, streamId, conversationId) =>
  GenerationJobManager.getGenerationAdmissionEvidence(
    userId,
    clientRequestId,
    streamId,
    conversationId,
  );

const subagentCompletionAdapter = createSubagentCompletionWakeupResolver({
  methods,
  getGenerationJob: (conversationId) => GenerationJobManager.getJob(conversationId),
  getScheduleMCPCompletionState: methods.getScheduleMCPCompletionState,
  getWaitMaxIntervalMs: () => service.getCompletionWaitMaxIntervalMs(),
});
const backgroundToolCompletionAdapter = createBackgroundToolCompletionWakeupResolver({
  methods,
  getGenerationJob: (conversationId) => GenerationJobManager.getJob(conversationId),
  getScheduleMCPCompletionState: methods.getScheduleMCPCompletionState,
  getResultBatchSize: () => service.getBackgroundCompletionResultBatchSize(),
  getGenerationAdmissionEvidence,
  recoverDeadClaim: createBackgroundToolDeadClaimRecovery(
    (...args) => service.retire(...args),
    methods.releaseBackgroundToolResultClaims,
    (conversationId) => GenerationJobManager.getJob(conversationId),
    ({ userId, conversationId, claimId }) =>
      GenerationJobManager.fenceGenerationClaimForRecovery(
        userId,
        claimId,
        conversationId,
        conversationId,
      ),
    methods.releaseAgentBackgroundToolResultClaims,
    methods,
    getGenerationAdmissionEvidence,
  ),
  getWaitMaxIntervalMs: () => service.getCompletionWaitMaxIntervalMs(),
});
const eventActorAdapter = createAgentEventContinueResolver({
  methods,
  getGenerationJob: (conversationId) => GenerationJobManager.getJob(conversationId),
});
let service;
const queuedTurnLifecycle = createAgentQueuedTurnLifecycle({
  methods,
  getGenerationJob: (conversationId) => GenerationJobManager.getJob(conversationId),
  completeSteerHandoff: (handoff) =>
    completePromotedSteerHandoff(GenerationJobManager.steering, handoff),
  getGenerationAdmissionEvidence,
  enqueue: (...args) => service.enqueue(...args),
  retireDelivery: (...args) => service.retire(...args),
  getDelivery: (...args) => service.getDelivery(...args),
});

service = createAgentTriggerService({
  sourceDispatchers: require('../Responses').backgroundResponseSourceDispatchers,
  methods,
  reclaimCheckpointDeletions: createCheckpointDeletionReclaimer((userId, tenantId) =>
    GenerationJobManager.getAccountCleanupJobIdsForUser(userId, tenantId),
  ),
  isPrincipalActive: methods.isAgentTriggerPrincipalActive,
  supportsDetachedActionCompletion: () => GenerationJobManager.supportsDetachedAgentEventActions,
  subscribeGenerationSettled: (listener) => GenerationJobManager.onGenerationSettled(listener),
  settleSourceBeforeDeadLetter: queuedTurnLifecycle.settleBeforeDeadLetter,
  prepareContinue: createAgentContinuationResolver({
    eventActor: eventActorAdapter,
    internalSources: new Map([
      [SUBAGENT_COMPLETION_SOURCE, subagentCompletionAdapter],
      [BACKGROUND_TOOL_COMPLETION_SOURCE, backgroundToolCompletionAdapter],
      [AGENT_QUEUED_TURN_SOURCE, queuedTurnLifecycle.prepareContinue],
    ]),
  }),
});

const initializeAgentTriggerService = async (options) => {
  await service.initialize(options);
  await queuedTurnLifecycle.initialize({
    maxIdleIntervalMs: options?.idlePolling?.queuedTurnMaxIntervalMs,
  });
};

const stopAgentTriggerService = async () => {
  await queuedTurnLifecycle.stop();
  await service.stop();
};

const purgeAgentTriggerDeliveriesForUser = async (userId) => {
  await service.purgeUser(userId);
};

module.exports = {
  isAgentTriggerServiceReady: service.isReady,
  initializeAgentTriggerService,
  stopAgentTriggerService,
  dispatchAgentTrigger: service.dispatch,
  enqueueAgentTrigger: service.enqueue,
  getAgentTriggerDelivery: service.getDelivery,
  getAgentTriggerDeliveryStatus: service.getDeliveryStatus,
  getAgentTriggerDeadLetters: service.getDeadLetters,
  requeueAgentTrigger: service.requeue,
  retireAgentTrigger: service.retire,
  renewAgentTriggerProducerLease: service.renewProducerLease,
  persistAgentBackgroundToolResult: service.persistBackgroundToolResult,
  expediteCompletionWakeups: service.expediteCompletionWakeups,
  getAgentBackgroundToolResultClaim: service.getBackgroundToolResultClaim,
  getBackgroundCompletionReceiptBatching: service.getBackgroundCompletionReceiptBatching,
  releaseAgentBackgroundToolResultClaims: service.releaseBackgroundToolResultClaims,
  drainAgentTriggerDeliveriesForUser: service.drainUser,
  prepareAgentTriggerUserPurge: service.prepareUserPurge,
  cancelAgentTriggerUserPurge: service.cancelUserPurge,
  purgeAgentTriggerDeliveriesForUser,
  scheduleAgentQueuedTurn: queuedTurnLifecycle.schedule,
  cancelAgentQueuedTurn: queuedTurnLifecycle.cancel,
  settleAgentQueuedTurnExecutionAdmission: queuedTurnLifecycle.recordExecutionAdmission,
  verifyAgentQueuedTurnExecutionAdmission: queuedTurnLifecycle.verifyExecutionAdmission,
};
