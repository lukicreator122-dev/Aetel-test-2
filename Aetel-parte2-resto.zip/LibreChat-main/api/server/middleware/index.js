const blockRetiredSetupToken = require('./blockRetiredSetupToken');
const validatePasswordReset = require('./validatePasswordReset');
const setTwoFactorTempUser = require('./setTwoFactorTempUser');
const { setTwoFactorAcknowledgementTempUser, setTwoFactorFinalizationTempUser } =
  setTwoFactorTempUser;
const validateRegistration = require('./validateRegistration');
const buildEndpointOption = require('./buildEndpointOption');
const validateEmailLogin = require('./validateEmailLogin');
const validateMessageReq = require('./validateMessageReq');
const {
  canReadActiveJobConversation,
  createMessageRequestValidation,
  prepareMessageRequestValidation,
  sendValidationResponse,
} = require('./messageValidation');
const checkDomainAllowed = require('./checkDomainAllowed');
const { markOAuthNavigation } = require('./oauthNavigation');
const requireSameOrigin = require('./requireSameOrigin');
const requireLocalAuth = require('./requireLocalAuth');
const canDeleteAccount = require('./canDeleteAccount');
const accessResources = require('./accessResources');
const requireLdapAuth = require('./requireLdapAuth');
const abortMiddleware = require('./abortMiddleware');
const checkInviteUser = require('./checkInviteUser');
const requireJwtAuth = require('./requireJwtAuth');
const {
  requireRumProxyAuth,
  requireTermsAcceptance,
  requireTermsAcceptanceOnRead,
} = require('./requireJwtAuth');
const configMiddleware = require('./config/app');
const { strictConfigMiddleware, loadStreamKeepaliveMs } = require('./config/app');
const validateModel = require('./validateModel');
const moderateText = require('./moderateText');
const logHeaders = require('./logHeaders');
const setHeaders = require('./setHeaders');
const validate = require('./validate');
const limiters = require('./limiters');
const uaParser = require('./uaParser');
const checkBan = require('./checkBan');
const noIndex = require('./noIndex');

module.exports = {
  ...abortMiddleware,
  ...validate,
  ...limiters,
  ...accessResources,
  noIndex,
  checkBan,
  uaParser,
  setHeaders,
  logHeaders,
  markOAuthNavigation,
  moderateText,
  validateModel,
  requireJwtAuth,
  requireRumProxyAuth,
  requireTermsAcceptance,
  requireTermsAcceptanceOnRead,
  setTwoFactorTempUser,
  setTwoFactorAcknowledgementTempUser,
  setTwoFactorFinalizationTempUser,
  blockRetiredSetupToken,
  checkInviteUser,
  requireLdapAuth,
  requireLocalAuth,
  requireSameOrigin,
  canDeleteAccount,
  configMiddleware,
  strictConfigMiddleware,
  loadStreamKeepaliveMs,
  checkDomainAllowed,
  validateMessageReq,
  canReadActiveJobConversation,
  sendValidationResponse,
  createMessageRequestValidation,
  prepareMessageRequestValidation,
  buildEndpointOption,
  validateRegistration,
  validatePasswordReset,
  validateEmailLogin,
};
